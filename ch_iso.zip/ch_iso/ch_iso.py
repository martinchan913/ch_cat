import tkinter as tk
import win32api,win32con
from tkinter import *
import os
import shutil
import winshell

def tk_cat():
    root_window = tk.Tk()
    # 设置窗口title
    root_window.title("康娃儿的乐色桶")
    # 设置窗口大小
    root_window.geometry('400x200')
    # 更改左上角窗口的的icon图标
    root_window.iconbitmap('full.ico')
    # 设置主窗口的背景颜色,颜色值可以是英文单词，或者颜色值的16进制数,除此之外还可以使用Tk内置的颜色常量
    root_window.config(background='#FFFFF0')
    # 添加文本内,设置字体的前景色和背景色，和字体类型、大小
    text = tk.Label(root_window, text="恭喜你，你是个有品位的人！", bg="#FFFFF0", fg="black", font=('Times', 20, 'bold italic'))
    # 将文本内容放置在主窗口内
    text.pack()
    # 添加按钮，以及按钮的文本，并通过command 参数设置更改图片的功能
    button1 = tk.Button(root_window, text="一键更换", command=ch_reg)
    # 将按钮放置在主窗口内
    button1.pack(side="bottom")
    #按钮位置
    # button1.place(x=150, y=100)
    #增加图片
    canvas = tk.Canvas(root_window, bg='white', height=768, width=1024)
    image_file = tk.PhotoImage(file='3.png')
    image_file1 = tk.PhotoImage(file='2.png')
    image1 = canvas.create_image(20, 0, anchor='nw', image=image_file1)
    image = canvas.create_image(250, 0, anchor='nw', image=image_file)
    canvas.pack()
    root_window.mainloop()
def ch_reg():
    # 变量设置
    reg_root=win32con.HKEY_CURRENT_USER
    ico_path=r'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\CLSID\\{645FF040-5081-101B-9F08-00AA002F954E}\\DefaultIcon'
    reg_flags = win32con.WRITE_OWNER | win32con.KEY_WOW64_64KEY | win32con.KEY_ALL_ACCESS
    #更改对应键值
    key = win32api.RegOpenKeyEx(reg_root, ico_path, 0, reg_flags)
    win32api.RegSetValueEx(key, 'full', 0, win32con.REG_EXPAND_SZ, "%ProgramFiles%\cat_ico\\full1.ico")
    win32api.RegSetValueEx(key, 'empty', 0, win32con.REG_EXPAND_SZ, "%ProgramFiles%\cat_ico\empty1.ico")
    win32api.RegCloseKey(key)
    winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=False)  # 清空回收站
def mkico():
    if not os.path.exists('C:\Program Files\cat_ico'):
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs('C:\Program Files\cat_ico')
        print('C:\Program Files\cat_ico' + ' 创建成功')
    base_dir = os.path.dirname(__file__)
    print(base_dir)
    if not os.path.isfile('empty1.ico'):
        shutil.copyfile("empty.ico", "empty1.ico")
    if not os.path.isfile('full1.ico'):
        shutil.copyfile("full.ico", "full1.ico")
    shutil.move(r"empty1.ico", r"C:\Program Files\cat_ico\empty1.ico")
    shutil.move(r"full1.ico", r"C:\Program Files\cat_ico\full1.ico")
if __name__ == '__main__':
    mkico()
    tk_cat()
